var ID_Copyright = "&copy; 2015-2021 VMware, Inc. All rights reserved.";
var ID_VersionInformation = "Revision 15-Sep-2021 &nbsp;|&nbsp;VMware vSAN Management API &nbsp;|&nbsp; Version 7.0U3";

